package Wearable;

public abstract class Wearable {
    protected boolean formal = false;
    public abstract boolean isFormal();
    public abstract String toString();
}
