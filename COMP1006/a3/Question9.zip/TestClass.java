import java.util.Arrays;

public class TestMatch {
	public static void main(String[] args){
		LinkedList list = new LinkedList();
		Node n1 = new Node("a");
		Node n2 = new Node("b");
		Node n3 = new Node("c");
		list.addNodeToBeginning(n1);
		list.addNodeToBeginning(n2);
		list.addNodeToEnd(n3);
		list.print();
		list.removeNodeFromBeginning();
		list.print();
		System.out.println(list.concatenate());
	}
}